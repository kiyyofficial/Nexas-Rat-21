# ☠️ NEXAS RAT — DEATH PROTOCOL ☠️

**Remote Access Toolkit | Enterprise Edition**  
*Powered by KiYY OFFICIAL — 2026*

> ⚠️ **PERINGATAN KERAS**  
> Penggunaan tanpa izin melanggar hukum pidana (UU ITE, Computer Fraud and Abuse Act).  
> Hanya untuk tujuan pendidikan etis & pengujian keamanan dengan izin tertulis.  
> Penulis tidak bertanggung jawab atas penyalahgunaan.

---

## 🔥 FITUR UTAMA

| Modul | Fitur | Status |
|-------|-------|--------|
| **RAT Control** | GPS, Kamera, Mikrofon, Screenshot, Keylogger, SMS, Kontak, File Manager, Shell, Notifikasi | ✅ REAL |
| **App Interaction** | Buka WhatsApp, Balas Chat WA, Buka Gmail | ✅ REAL |
| **Remote Touch** | Tap, Long Press, Swipe (AccessibilityService) | ✅ REAL |
| **App Launcher** | Daftar & buka aplikasi terinstal | ✅ REAL |
| **WhatsApp Gateway** | Pairing Code, Kirim perintah via WA | ✅ REAL |
| **WhatsApp Exploit** | Force Close Loop, Delay, Onehit, Spam Call, Spam Pair | ✅ REAL |
| **User Management** | Akun dengan expiry date (untuk dijual), admin tidak expire | ✅ REAL |
| **Panel Web** | Login premium, hamburger menu, device history, help | ✅ REAL |

---
Powered by KiYY OFFICIAL ©2026 New apk 
Di buat pada hari dan tanggal : kamis 14 mei 2026 
Support:
My pacar 
Ortu 
Guru

Struktur pembuat / developer:
- Sanz Official ( Partner utama )
- Rifz Official ( Partner + Kawan my ) 
- Kyy Official ( own )
- Hanz Official ( own )
- KiYY OFFICIAL ( developer asli apk )

thanks to atas kerjasamanya 😇


## 📦 STRUKTUR PROYEK
